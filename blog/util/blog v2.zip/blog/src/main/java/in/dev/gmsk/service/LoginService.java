package in.dev.gmsk.service;

public interface LoginService {

	boolean validateUser(String name, String password);
}
